Made by ttk20090



Manual

1.do not delete "List.txt" or else it will not work

2.displaying might not be great i recommend open the text files directly is better

3.there will be "new list" front of the text you input so if you want it to be clean. then do it by yourself manually



Thank you for using my Py files :)





Thai date:21/08/2567

International date: 8/21/2024
