print("add a new list here. Input 2 for displaying the list")
print("template:|รายรับ|                 |รายจ่าย|                        |รวม|")
answer = input("Input:")
if answer == "2":
    file = open("List.txt","r")
    print(file.readlines())
    print("display complete.")
else:
    file = open("List.txt","a")
    file.write("\nnew list:")
    file.write(answer)
    file.close
    print("Done the list has added.")
